"""Entrotter experimental release 0.1.0."""

__version__ = "0.1.0"
