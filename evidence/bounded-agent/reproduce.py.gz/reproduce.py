"""Re-execute archived public reports with the bounded worker; no model generation."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from entrotter_engine.artifact import verify
from entrotter_engine.runner import run, run_agent

root = Path('/Users/hatanakatomoya/Developer/App/Entrotter/entrotter-workspace/entrotter')
out = Path('/tmp/entrotter-agent-worker/reproduction')
out.mkdir(exist_ok=True)
paths = sorted((root / 'evidence/causal-v1').glob('causal-uniswap-*.json'))
paths += sorted((root / 'evidence').glob('agent-local-*.json'))
paths += [root / 'evidence/historical-uniswap.json']
results = []
for path in paths:
    raw = path.read_bytes()
    expected = json.loads(raw)
    if not verify(expected):
        raise ValueError('Invalid original report: ' + path.name)
    start = time.perf_counter()
    record = {'source_file': str(path.relative_to(root)), 'source_sha256': hashlib.sha256(raw).hexdigest(),
              'expected_artifact_id': expected['artifact_id'], 'mode': expected['mode'],
              'agent_replay': 'agent' in expected, 'started_at': datetime.now(timezone.utc).isoformat()}
    try:
        if 'agent' in expected:
            exchanges = expected['agent']['exchanges']
            actual = run_agent(expected['scenario'],
                               decision_steps=[x['request']['observation']['step'] for x in exchanges],
                               max_requested_gas=exchanges[0]['request']['limits']['remaining_requested_gas'],
                               recording=expected['agent'])
        else:
            actual = run(expected['scenario'])
        target = out / path.name
        target.write_text(json.dumps(actual, indent=2) + '\n')
        record.update(actual_artifact_id=actual['artifact_id'], exact=actual == expected,
                      output_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
    except Exception as exc:
        record.update(exact=False, error_type=type(exc).__name__, error=str(exc))
    record['elapsed_seconds'] = time.perf_counter() - start
    results.append(record)
    (out / 'summary.json').write_text(json.dumps({'model_calls': 0, 'results': results}, indent=2) + '\n')
    print(json.dumps(record), flush=True)
if len(results) != 19 or not all(x['exact'] for x in results):
    raise SystemExit(1)
