// Continuous actual Chromium recording; presentation frame is explicitly labelled.
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const here = dirname(fileURLToPath(import.meta.url));
const workspace = resolve(here, '../..');
const q = resolve(workspace, 'entrotter/.quality/account-summary-demo');
const out = resolve(workspace, 'entrotter/output/playwright/account-summary-demo');
const site = resolve(workspace, 'entrotter.github.io');
const engine = resolve(workspace, '.worktrees/engine-consumer-observations');
const require = createRequire(resolve(site, 'package.json'));
const { chromium } = require('playwright');
const hash = b => createHash('sha256').update(b).digest('hex');
const expectedSite = '8aa0e582dfa56ec795cf0adc83303ac1eb952528';
const expectedEngine = '88c6cd0d00f466ed7e870bd57c118aa50984f8b1';
const verifySource = (repo, expected) => {
  assert.equal(execFileSync('git', ['-C', repo, 'rev-parse', 'HEAD'], {encoding:'utf8'}).trim(), expected);
  execFileSync('git', ['-C', repo, 'diff', '--quiet']);
  execFileSync('git', ['-C', repo, 'diff', '--cached', '--quiet']);
};
verifySource(site, expectedSite); verifySource(engine, expectedEngine);
await mkdir(resolve(out, 'generated'), {recursive:true});
const timeline = JSON.parse(await readFile(resolve(here, 'audio/demo-timeline.json'), 'utf8'));
assert(timeline.duration < 174, 'Narration must leave room below the 3-minute limit');
const manifest = JSON.parse(await readFile(resolve(q, 'worker-image.json'), 'utf8'));
for (const [file, digest] of Object.entries(manifest.source_files)) {
  const path = file === 'Dockerfile' ? resolve(engine, 'container', file) : resolve(engine, 'src/entrotter_engine', file);
  assert.equal(hash(await readFile(path)), digest, file);
}
const original = await readFile(resolve(site, 'reports/aave-account-impact13.json'));
const originalText = original.toString('utf8');
const outerId = /^(\{\s*"artifact_id":\s*")([a-f0-9]{64})(")/;
const match = originalText.match(outerId); assert(match);
const invalid = originalText.replace(outerId, (_whole, prefix, _id, suffix) => prefix + '0'.repeat(64) + suffix);
assert.equal(invalid.replace(outerId, (_whole, prefix, _id, suffix) => prefix + match[2] + suffix), originalText);
assert.notEqual(invalid, originalText);
await writeFile(resolve(out, 'generated/account-original.json'), original);
await writeFile(resolve(out, 'generated/account-invalid.json'), invalid);
const served = new Map();
const types = {'.html':'text/html', '.js':'text/javascript', '.mjs':'text/javascript', '.css':'text/css', '.json':'application/json', '.png':'image/png', '.webp':'image/webp'};
const topFiles = new Set(['index.html','style.css','app.js','comparison.mjs','report-validation.mjs','trace-viewer.mjs','trace-report.mjs','trace-comparison.mjs','observed-trace.mjs','position-report.mjs','assets/examples/action-comparison.json']);
const server = createServer(async (req, res) => {
  try {
    assert.equal(req.method, 'GET');
    const url = new URL(req.url, 'http://127.0.0.1');
    let path;
    if (url.pathname === '/') path = resolve(here, 'studio.html');
    else if (url.pathname.startsWith('/site/')) {
      const name = url.pathname.slice(6) || 'index.html';
      if (!topFiles.has(name) && !/^(reports|schemas|assets)\/[a-zA-Z0-9_.-]+$/.test(name)) throw Error('Unlisted file');
      path = resolve(site, name);
    } else throw Error('Unknown route');
    const bytes = await readFile(path); served.set(url.pathname, hash(bytes));
    res.writeHead(200, {'Content-Type':types[extname(path)] || 'application/octet-stream', 'Cache-Control':'no-store'}).end(bytes);
  } catch { res.writeHead(404).end('Not found'); }
});
let browser, child, execution, runError, runComplete = false, stdout = '', childClosed;
const requests = [], responses = [], errors = [], events = [], checkpoints = [];
try {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({headless:true});
  const context = await browser.newContext({viewport:{width:1600,height:900}, deviceScaleFactor:1, recordVideo:{dir:resolve(out,'raw'),size:{width:1600,height:900}}});
  const page = await context.newPage();
  page.on('request', r => requests.push({url:r.url(),method:r.method()}));
  page.on('pageerror', e => errors.push(e.message));
  page.on('response', r => responses.push({url:r.url(),status:r.status()}));
  await page.goto(url);
  const product = page.frameLocator('#product');
  await product.locator('#hash').filter({hasText:/[0-9a-f]{64}/}).waitFor({state:'attached'});
  await page.evaluate(() => window.studio.mode('product','01 / THE ACTUAL VIEWER'));
  const shot = async name => { await page.screenshot({path:resolve(out,`demo-${name}.png`)}); checkpoints.push(name); };
  const start = performance.now(); let sceneIndex = -1, captionIndex = -1, recovered = false;
  while (performance.now() - start < timeline.duration * 1000) {
    const seconds = (performance.now() - start) / 1000;
    const next = timeline.scenes.findIndex(s => seconds >= s.start && seconds < s.end);
    if (next !== -1 && next !== sceneIndex) {
      sceneIndex = next; const scene = timeline.scenes[next];
      events.push({scene:scene.id,elapsed:seconds}); console.log(scene.id, seconds.toFixed(2));
      await page.evaluate(label => window.studio.mode('product',label), scene.label);
      if (scene.id === 'intro') await product.locator('h1').scrollIntoViewIfNeeded();
      if (scene.id === 'run') {
        await page.evaluate(label => window.studio.mode('console',label), scene.label);
        child = spawn(resolve(workspace,'.tools/quality-venv/bin/python'), [resolve(here,'live_run.py'),resolve(out,'generated')], {cwd:workspace,env:{...process.env,PYTHONPATH:resolve(engine,'src'),ENTROTTER_DOCKER_SOCKET:resolve(process.env.HOME,'.colima/default/docker.sock'),ENTROTTER_WORKER_IMAGE:manifest.image_id,ENTROTTER_EXPORT_STATE_DIR:resolve(out,'export-state')}});
        execution = new Promise((res,rej) => { child.on('error',rej); child.on('close',code => code === 0 ? res() : rej(Error(`Real execution failed: ${code}`))); });
        childClosed = new Promise(res => child.on('close',res));
        execution.then(() => runComplete = true).catch(e => runError = e);
        const append = data => { stdout += data.toString(); if (stdout.length > 65536) { runError = Error('Execution output limit'); child.kill('SIGTERM'); } };
        child.stdout.on('data',append); child.stderr.on('data',append);
      }
      if (scene.id === 'agent') {
        assert(runComplete, 'Actual run must finish within its narrated window');
        await product.locator('details.archive > summary').click();
        await product.locator('#import').setInputFiles(resolve(out,'generated/agent-replay.json'));
        await product.locator('#hash').filter({hasText:'1d1de88d01cbe23c494f6a6f7ee7127d63629baac071def58c067506ddf5893b'}).waitFor();
        assert.equal(await product.locator('#evm-traces tr').count(),4);
        await product.getByText('Supplied actions on isolated local forks',{exact:true}).evaluate(el => el.scrollIntoView({block:'start'}));
      }
      if (scene.id === 'account') {
        await product.locator('details.trace-archive > summary').click();
        await product.locator('#trace-account-sample').click();
        await product.locator('#trace-account-results').waitFor({state:'visible'});
        assert.equal(await product.locator('#trace-account-capacity-delta').innerText(), '+816.28966124');
        assert.equal(await product.locator('#trace-account-health-delta').innerText(), '+0.003852169807877337');
        await product.locator('#trace-account-results').evaluate(el => el.scrollIntoView({block:'start'}));
      }
      if (scene.id === 'scope') {
        await product.getByText('Four account phases in exact raw units',{exact:true}).click();
        assert.equal(await product.locator('#trace-account-rows tr').count(),4);
        await product.locator('#trace-account-rows').scrollIntoViewIfNeeded();
      }
      if (scene.id === 'receipts') {
        assert.equal(await product.locator('#trace-outcomes tr').count(),13);
        await product.locator('#trace-outcomes tr').last().evaluate(el => el.scrollIntoView({block:'end'}));
      }
      if (scene.id === 'invalid') {
        await product.locator('#trace-import').setInputFiles(resolve(out,'generated/account-invalid.json'));
        await product.locator('#trace-status.error').waitFor();
        assert.equal(await product.locator('#trace-account-capacity-delta').textContent(),'');
        assert.equal(await product.locator('#trace-account-health-delta').textContent(),'');
        assert(await product.locator('#trace-account-results').isHidden());
        await product.locator('#trace-status').scrollIntoViewIfNeeded();
      }
      if (scene.id === 'end') await page.evaluate(() => window.studio.slide({id:'close',eyebrow:'REPRODUCE / REVIEW / CONTRIBUTE',title:'Bring one decision\nyou need to explain.',body:'entrotter.github.io · github.com/entrotter',lines:['Two fresh local runs · one recorded historical case','Exact account changes · complete receipt evidence','Review branches · main integration and Pages pending']},7));
      await shot(scene.id);
    }
    if (runError) throw runError;
    if (timeline.scenes[sceneIndex]?.id === 'run') await page.evaluate(text => window.studio.output(text),stdout);
    const cue = timeline.captions.findIndex(c => seconds >= c.start && seconds < c.end);
    if (cue !== captionIndex) {
      captionIndex = cue;
      await page.evaluate(({text,pct}) => window.studio.caption(text,pct), {text:cue >= 0 ? timeline.captions[cue].text : '',pct:Math.min(100,seconds/timeline.duration*100)});
      if (cue >= 0 && timeline.captions[cue].scene === 'agent' && timeline.captions[cue].text.startsWith('The report')) {
        assert.equal(await product.locator('#agent-rows tr').count(),2);
        await product.getByText('Decision-time evidence and candidate receipts (gas in exact units)',{exact:true}).evaluate(el => el.scrollIntoView({block:'start'}));
        await shot('agent-decisions');
      }
      if (cue >= 0 && timeline.captions[cue].scene === 'receipts' && timeline.captions[cue].text.startsWith('Expand')) {
        await product.getByText('Transaction 12: exact original, baseline and candidate receipt fields',{exact:true}).click();
        const pre = product.locator('#trace-receipts details').nth(12).locator('pre');
        await pre.evaluate(el => { el.scrollIntoView({block:'center'}); el.scrollTop = el.scrollHeight; });
        assert((await pre.innerText()).includes('"candidate": null'));
        await shot('receipt-skipped-candidate');
      }
      if (cue >= 0 && timeline.captions[cue].scene === 'invalid' && timeline.captions[cue].text.startsWith('Importing') && !recovered) {
        await product.locator('#trace-import').setInputFiles(resolve(out,'generated/account-original.json'));
        await product.locator('#trace-account-results').waitFor({state:'visible'});
        assert.equal(await product.locator('#trace-account-capacity-delta').innerText(),'+816.28966124');
        await product.locator('#trace-account-results').evaluate(el => el.scrollIntoView({block:'start'}));
        recovered = true; await shot('recovered');
      }
    }
    await new Promise(r => setTimeout(r,80));
  }
  await execution; assert(runComplete); assert(recovered); assert.equal(events.length,8); assert.equal(errors.length,0);
  assert(requests.every(r => r.url.startsWith(url + '/') && r.method === 'GET'));
  assert(responses.length === requests.length && responses.every(r => r.status === 200));
  verifySource(site,expectedSite); verifySource(engine,expectedEngine);
  await writeFile(resolve(out,'actual-execution.log'),stdout);
  await writeFile(resolve(out,'demo-capture.json'),JSON.stringify({browser:browser.version(),duration:timeline.duration,capture_wall_seconds:(performance.now()-start)/1000,events,checkpoints,requests,responses,errors,real_execution_complete:runComplete,recovered,source:{viewer:expectedSite,engine:expectedEngine,image_id:manifest.image_id},served_sha256:Object.fromEntries(served),scope:'Continuous actual viewer capture. Two fresh bounded local runs; account13 is previously recorded and only inspected. No model, archive, upload or external browser requests.'},null,2)+'\n');
  const video = page.video(); await context.close(); await video.saveAs(resolve(out,'demo-capture.webm'));
} catch (error) {
  await writeFile(resolve(out,'failure.json'),JSON.stringify({error:String(error),events,requests,responses,errors},null,2)+'\n');
  throw error;
} finally {
  await writeFile(resolve(out,'actual-execution.log'),stdout);
  if (child && child.exitCode === null) { child.kill('SIGTERM'); await childClosed; }
  if (browser) await browser.close();
  if (server.listening) await new Promise(r => server.close(r));
}
