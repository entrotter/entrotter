"""Mux the new continuous capture only; preserve all owner-approved originals."""
import json
from pathlib import Path
import subprocess
workspace = Path(__file__).resolve().parents[2]
raw = workspace / 'entrotter/output/playwright/account-summary-demo'
q = workspace / 'entrotter/.quality/account-summary-demo'
media = workspace / 'entrotter/submission/media'
source = raw / 'demo-capture.webm'
probe = json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_format','-show_streams','-of','json',str(source)]))
capture = json.loads((raw / 'demo-capture.json').read_text())
duration = float(probe['format']['duration'])
assert duration <= 180
# Playwright starts video before the narrated capture loop; retain that lead-in.
offset = max(0, duration - capture['capture_wall_seconds'])
target = media / 'entrotter-demo-account.mp4'
command = ['ffmpeg','-y','-hide_banner','-i',str(source),'-itsoffset',str(offset),'-i',str(workspace / '.tools/entrotter-account-demo/audio/demo.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-ar','48000','-af','loudnorm=I=-16:TP=-1.5:LRA=11','-movflags','+faststart','-t',str(duration),'-metadata','title=Entrotter account comparison — October 3 review cut',str(target)]
with (q / 'encode.log').open('w') as log:
    subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
timeline = json.loads((workspace / '.tools/entrotter-account-demo/audio/demo-timeline.json').read_text())
def stamp(value, comma=False):
    milliseconds=round(value*1000);seconds,ms=divmod(milliseconds,1000);minutes,s=divmod(seconds,60);h,m=divmod(minutes,60)
    return f'{h:02}:{m:02}:{s:02}'+(',' if comma else '.')+f'{ms:03}'
vtt=['WEBVTT',''];srt=[]
for i,c in enumerate(timeline['captions'],1):
    assert c['end']+offset <= duration
    vtt += [f"{stamp(c['start']+offset)} --> {stamp(c['end']+offset)}",c['text'],'']
    srt += [str(i),f"{stamp(c['start']+offset,True)} --> {stamp(c['end']+offset,True)}",c['text'],'']
(media / 'entrotter-demo-account.vtt').write_text('\n'.join(vtt)+'\n')
(media / 'entrotter-demo-account.srt').write_text('\n'.join(srt)+'\n')
final = json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_format','-show_streams','-of','json',str(target)]))
assert float(final['format']['duration']) <= 180
video = [s for s in final['streams'] if s['codec_type']=='video']; audio = [s for s in final['streams'] if s['codec_type']=='audio']
assert len(video)==len(audio)==1
assert video[0]['codec_name']=='h264' and video[0]['width']==1600 and video[0]['height']==900
assert audio[0]['codec_name']=='aac' and audio[0]['sample_rate']=='48000'
(q / 'encode-results.json').write_text(json.dumps({'audio_offset_seconds':offset,'continuous_capture_seconds':duration,'probe':final,'caption_count':len(timeline['captions'])},indent=2)+'\n')
with (q / 'decode.log').open('w') as log:
    subprocess.run(['ffmpeg','-hide_banner','-v','error','-xerror','-i',str(target),'-f','null','-'],stdout=log,stderr=subprocess.STDOUT,check=True)
with (q / 'audio-analysis.log').open('w') as log:
    subprocess.run(['ffmpeg','-hide_banner','-i',str(target),'-vn','-af','ebur128=peak=true','-f','null','-'],stdout=log,stderr=subprocess.STDOUT,check=True)
assert (q / 'decode.log').stat().st_size==0
for scene in ['run','agent','account','scope','receipts','invalid','end']:
    event=next(e for e in capture['events'] if e['scene']==scene)
    seconds=event['elapsed']+offset+4
    subprocess.run(['ffmpeg','-y','-v','error','-ss',str(seconds),'-i',str(target),'-frames:v','1',str(q / f'final-{scene}.png')],check=True)
print(json.dumps({'duration':final['format']['duration'],'bytes':target.stat().st_size,'decode_errors':0,'captions':len(timeline['captions']),'offset':offset}),flush=True)
