"""Fresh bounded local execution for the new cut; recorded historical file is separate."""
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
from entrotter_engine.artifact import verify, write_report
from entrotter_engine.runner import run_agent

def cancel(signum, frame):
    raise KeyboardInterrupt("Recording cancelled")
signal.signal(signal.SIGTERM, cancel)
workspace = Path(__file__).resolve().parents[2]
out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=True)
reference = json.loads((workspace / 'entrotter/evidence/agent-local-codex.json').read_text())
assert verify(reference) and reference['scenario']['mode'] == 'evm-local'
os.environ.pop('ENTROTTER_RPC_URL', None)
started = time.perf_counter()
print('Engine 88c6cd0 / local EVM / bounded Docker worker', flush=True)
print('run_agent(scenario, decision_steps=[0, 1])', flush=True)
risk = run_agent(reference['scenario'], decision_steps=[0, 1])
print('Risk choices: ' + ', '.join(x['response']['choice'] for x in risk['agent']['exchanges']), flush=True)
print('Baseline: ' + ', '.join(x['status'] for x in risk['baseline']['trace']), flush=True)
print('Candidate: ' + ', '.join(x['status'] for x in risk['candidate']['trace']), flush=True)
print('\nReplaying recorded model decisions against fresh observations...', flush=True)
replayed = run_agent(reference['scenario'], decision_steps=[0, 1], recording=reference['agent'])
assert replayed == reference and verify(replayed)
write_report(replayed, out / 'agent-replay.json')
print('Complete JSON equality: true', flush=True)
print('Artifact: ' + replayed['artifact_id'], flush=True)
print('Agent model calls: 0 | archive requests: 0', flush=True)
elapsed = time.perf_counter() - started
print(f'Actual local execution time: {elapsed:.3f} seconds', flush=True)
(out / 'execution.json').write_text(json.dumps({'complete_json_equality': True, 'artifact_id': replayed['artifact_id'], 'risk_artifact_id': risk['artifact_id'], 'agent_model_calls': 0, 'archive_requests': 0, 'elapsed_seconds': elapsed, 'source': '88c6cd0d00f466ed7e870bd57c118aa50984f8b1', 'image_id': os.environ['ENTROTTER_WORKER_IMAGE'], 'report_sha256': hashlib.sha256((out / 'agent-replay.json').read_bytes()).hexdigest(), 'scope': 'Two actual local bounded worker calls; historical account13 is a separate previously recorded file.'}, indent=2) + '\n')
