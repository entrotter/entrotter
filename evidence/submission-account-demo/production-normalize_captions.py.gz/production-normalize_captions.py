"""Remove only surplus EOF blank lines; preserve all caption cues and timing."""
import hashlib
import json
from pathlib import Path
workspace = Path(__file__).resolve().parents[2]
q = workspace / 'entrotter/.quality/account-summary-demo'
changes = {}
for suffix in ['vtt', 'srt']:
    p = workspace / 'entrotter/submission/media' / f'entrotter-demo-account.{suffix}'
    before = p.read_bytes()
    (q / f'captions-before-normalization.{suffix}').write_bytes(before)
    after = before.rstrip(b'\n') + b'\n'
    assert before.rstrip(b'\n') == after.rstrip(b'\n')
    p.write_bytes(after)
    changes[suffix] = {'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'before_bytes':len(before),'after_bytes':len(after),'scope':'Only EOF surplus newline removal; no cue text, separator, order or timestamp changes.'}
(q / 'caption-normalization.json').write_text(json.dumps(changes,indent=2)+'\n')
