"""Package only final current cut, with explicit historical/fresh evidence scopes."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
workspace = Path(__file__).resolve().parents[2]
r = workspace / 'entrotter'
q = r / '.quality/account-summary-demo'
raw = r / 'output/playwright/account-summary-demo'
h = workspace / '.tools/entrotter-account-demo'
pub = r / 'evidence/submission-account-demo'
pub.mkdir(exist_ok=True)
H = lambda b: hashlib.sha256(b).hexdigest()
source_helpers = {}
for name in ['record.mjs','live_run.py','encode.py','studio.html','scenes.json','narrate.py','normalize_captions.py','package.py']:
    b=(h/name).read_bytes(); target=pub/f'production-{name}.gz'; target.write_bytes(gzip.compress(b,mtime=0)); source_helpers[name]=H(b)
for name,src in {
    'capture.json':raw/'demo-capture.json',
    'timeline.json':h/'audio/demo-timeline.json',
    'actual-execution.log':raw/'actual-execution.log',
    'execution.json':raw/'generated/execution.json',
    'agent-replay.json':raw/'generated/agent-replay.json',
    'original-media-sha256.json':q/'original-media-sha256.json',
    'negative-input-fix.json':q/'negative-input-fix.json',
    'worker-image.json':q/'worker-image.json',
    'cleanup.json':q/'cleanup.json',
    'caption-normalization.json':q/'caption-normalization.json',
}.items(): shutil.copyfile(src,pub/name)
# FFprobe retains its original absolute local filename privately. Public copy changes only that location.
probe=json.loads((q/'encode-results.json').read_text());private_filename=probe['probe']['format']['filename'];probe['probe']['format']['filename']='submission/media/entrotter-demo-account.mp4'
(pub/'encoding.json').write_text(json.dumps(probe,indent=2)+'\n')
for name in ['account','agent','receipts','invalid','end']:
    shutil.copyfile(q/f'final-{name}.png',pub/f'frame-{name}.png')
rootCI=r/'.quality/account-summary-integration/ci-3b9d/independent-ci-review.json'
manifest={
 'status':'recorded_new_review_cut',
 'source':{'coordination':'3b9d24e8b169c325fcb9c99929fb6559733847e3','engine':'88c6cd0d00f466ed7e870bd57c118aa50984f8b1','viewer':'8aa0e582dfa56ec795cf0adc83303ac1eb952528','sdk':'ba4af512784119f23b6dea63fd24c7f5d1fdde44','cli':'696511c5cb46482c96cf6f609c83877fcf16e922'},
 'media':{str(p.relative_to(r)):{'sha256':H(p.read_bytes()),'bytes':p.stat().st_size} for p in (r/'submission/media').glob('entrotter-demo-account.*')},
 'duration_seconds':float(probe['probe']['format']['duration']),
 'continuous_capture_seconds':probe['continuous_capture_seconds'],
 'narration_audio_offset_seconds':probe['audio_offset_seconds'],
 'caption_count':probe['caption_count'],
 'production_helper_sha256':source_helpers,
 'public_evidence_sha256':{p.name:H(p.read_bytes()) for p in sorted(pub.iterdir()) if p.is_file() and p.name not in ['manifest.json','README.md','independent-review.json']},
 'local_raw_sha256':{str(p.relative_to(workspace)):H(p.read_bytes()) for p in [raw/'demo-capture.webm',h/'audio/demo.wav',q/'encode-results.json',q/'decode.log',q/'audio-analysis.log',q/'record.log']},
 'voice':json.loads((q/'original-media-and-voice-rehash.json').read_text()),
 'root_current_ci_before_media_change_sha256':H(rootCI.read_bytes()),
 'caption_derivation':json.loads((q/'caption-normalization.json').read_text()),
 'negative_input':json.loads((q/'negative-input-fix.json').read_text()),
 'execution':json.loads((raw/'generated/execution.json').read_text()),
 'verification':{'complete_decode_exit':0,'decode_errors':0,'full_decode_log_sha256':H((q/'decode.log').read_bytes()),'all_original_media_unchanged':True,'page_errors':0,'loopback_GET_requests':len(json.loads((raw/'demo-capture.json').read_text())['requests']),'all_requested_product_resources_status200':True,'owned_worker_containers_remaining':0},
 'attempts':{
  'first':{'scope':'Retained partial capture; missing actual explorer-open operation caused a hidden hash wait timeout. Two local calls passed but helper did not persist child stdout; that gap is not reconstructed.'},
  'second':{'scope':'Retained successful 156.88s cut, original exact helpers and independent negative review bfc12a21. Nested comparison asset returned404, lossily serialized invalid file also rounded two health-factor integers, account/receipt framing obscured relevant table. This cut is not selected.'},
  'third':{'scope':'Retained partial capture and exact helper; owned browser deliberately cancelled after precision finding. Recorder caught cancellation and persisted stdout/failure; not selected.'},
  'final':{'scope':'Complete continuous capture using lossless64-byte identifier-only negative input, exact nested asset allowlist, all200responses and readable account/receipt framing. No change to product or narration between last two attempts.'}
 },
 'limits':['Two fresh bounded local agent calls; account13 is previously recorded historical evidence inspected offline, not a new chain run.','Four attempts/extra local calls are authoring work, not controlled timing comparisons or model calls.','No sole-price causality, profit, trading/borrowing strategy, provider/proxy authenticity, full-block/state-root proof or market prediction.','Browser/server closed; only owned worker containers checked; existing local Docker VM and unrelated services remain running.','Current rebuilt local arm64 image has exact23 sources/pinnedbase; no fresh image advisory scan is implied by the recording.','The archive wrappers preserve one-off local harnesses; not installed production modules or a portable supported media generation command.','Public FFprobe filename normalized to repository-relative; original retained privately. Captions remove only one surplus EOF newline per file; original bytes and all unchanged cues retained.','Human auditory review pending; automated audio/decode and visual checks are separate.','Original owner-approved videos unchanged; new cut is additional material, no hosting/upload/submission or main/Pages deployment.']
}
assert manifest['duration_seconds']<=180 and manifest['caption_count']==15
for name,digest in json.loads((q/'original-media-sha256.json').read_text()).items():assert H((workspace/name).read_bytes())==digest
(pub/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for p in pub.iterdir():
 if p.suffix in ['.json','.log','.md']:assert str(Path.home()).encode() not in p.read_bytes(),p
for p in pub.glob('*.gz'):
 assert str(Path.home()).encode() not in gzip.decompress(p.read_bytes()),p
print('Packaged final current demo evidence; original10mediafiles unchanged; no private owner paths in public text')
