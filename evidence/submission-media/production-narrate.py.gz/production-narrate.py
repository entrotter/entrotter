"""Local production helper; synthesize original scripts with a pinned public voice."""
import json
from pathlib import Path
import wave
import onnxruntime
from piper import PiperVoice, SynthesisConfig
from piper.config import PiperConfig

root = Path(__file__).resolve().parents[1]
out = root / 'audio'
out.mkdir(exist_ok=True)
options = onnxruntime.SessionOptions()
options.intra_op_num_threads = 2
options.inter_op_num_threads = 1
voice = PiperVoice(config=PiperConfig.from_dict(json.loads((root/'en_US-ljspeech-high.onnx.json').read_text())),
                   session=onnxruntime.InferenceSession(str(root/'en_US-ljspeech-high.onnx'), sess_options=options, providers=['CPUExecutionProvider']),
                   download_dir=root)
scenes = json.loads((root/'production/scenes.json').read_text())
for kind, sections in scenes.items():
    cursor = 1.0
    chunks = []
    captions = []
    for scene in sections:
        scene['start'] = cursor
        for i, text in enumerate(scene['narration']):
            path = out / f"{kind}-{scene['id']}-{i}.wav"
            with wave.open(str(path),'wb') as audio:
                voice.synthesize_wav(text,audio,syn_config=SynthesisConfig(length_scale=0.93,noise_scale=0.55,noise_w_scale=0.7))
            with wave.open(str(path),'rb') as audio:
                frames = audio.readframes(audio.getnframes())
                rate = audio.getframerate()
                seconds = audio.getnframes()/rate
            captions.append({'start':cursor,'end':cursor+seconds,'text':text,'scene':scene['id']})
            chunks.append(frames+b'\0\0'*round(rate*0.45))
            cursor += seconds+0.45
        scene['end'] = cursor+0.5
        chunks.append(b'\0\0'*round(rate*0.5))
        cursor+=0.5
    with wave.open(str(out/f'{kind}.wav'),'wb') as target:
        target.setnchannels(1);target.setsampwidth(2);target.setframerate(rate)
        target.writeframes(b'\0\0'*rate + b''.join(chunks)+b'\0\0'*rate)
    (out/f'{kind}-timeline.json').write_text(json.dumps({'scenes':sections,'captions':captions,'duration':cursor+1.0},indent=2)+'\n')
    print(kind,round(cursor+1.0,3),'seconds',sum(len(x['text'].split()) for x in captions),'words',flush=True)
