"""Actual bounded demonstration; public local scenario, no model or upstream RPC."""
import json
import os
from pathlib import Path
import time
from entrotter_engine.agent import ReplayPolicy
from entrotter_engine.artifact import verify,write_report
from entrotter_engine.runner import run_agent

workspace=Path(__file__).resolve().parents[3]
out=workspace/'entrotter/output/playwright/submission/generated'
out.mkdir(parents=True,exist_ok=True)
reference=json.loads((workspace/'entrotter/evidence/agent-local-codex.json').read_text())
assert verify(reference)
assert reference['scenario']['mode']=='evm-local'
os.environ.pop('ENTROTTER_RPC_URL',None)
started=time.perf_counter()
print('run_agent(scenario, decision_steps=[0, 1])',flush=True)
risk=run_agent(reference['scenario'],decision_steps=[0,1])
print('Risk choices:     '+', '.join(x['response']['choice'] for x in risk['agent']['exchanges']),flush=True)
print('Baseline status:  '+', '.join(x['status'] for x in risk['baseline']['trace']),flush=True)
print('Candidate status: '+', '.join(x['status'] for x in risk['candidate']['trace']),flush=True)
print('\nrun_agent(scenario, decision_steps=[0, 1], recording=record)',flush=True)
replayed=run_agent(reference['scenario'],decision_steps=[0,1],recording=reference['agent'])
assert replayed==reference and verify(replayed)
print('Complete JSON equality: true',flush=True)
print('Artifact: '+replayed['artifact_id'],flush=True)
write_report(replayed,out/'agent-replay.json')
invalid=dict(replayed);invalid['artifact_id']='0'*64
(out/'invalid-hash.json').write_text(json.dumps(invalid,indent=2)+'\n')
print('Saved: agent-replay.json  |  Agent model calls: 0',flush=True)
print(f'Actual execution time: {time.perf_counter()-started:.3f} seconds',flush=True)
(out/'execution.json').write_text(json.dumps({'exact':True,'artifact_id':replayed['artifact_id'],'agent_model_calls':0,'elapsed_seconds':time.perf_counter()-started,'risk_artifact_id':risk['artifact_id']},indent=2)+'\n')
