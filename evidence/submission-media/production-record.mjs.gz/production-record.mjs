// Actual Chromium recording, with an explicitly labelled presentation/console frame.
import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,dirname,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const here=dirname(fileURLToPath(import.meta.url));
const workspace=resolve(here,'../../..');
const require=createRequire(resolve(workspace,'entrotter.github.io/package.json'));
const {chromium}=require('playwright');
const output=resolve(workspace,'entrotter/output/playwright/submission');
const site=resolve(workspace,'entrotter.github.io');
await mkdir(output,{recursive:true});
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.webp':'image/webp'};
const server=createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://127.0.0.1');
  let path;
  if(url.pathname==='/')path=resolve(here,'studio.html');
  else if(url.pathname.startsWith('/site/')){
   const name=url.pathname.slice(6)||'index.html';
   if(!/^(index\.html|style\.css|app\.js|(?:reports|schemas|assets)\/[a-zA-Z0-9_.-]+)$/.test(name))throw Error('Unlisted file');
   path=resolve(site,name);
  }else throw Error('Unknown route');
  res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'no-store'}).end(await readFile(path));
 }catch{res.writeHead(404).end('Not found')}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url=`http://127.0.0.1:${server.address().port}`;
console.log(url);
if(process.argv.includes('--preview')){
 await writeFile(resolve(output,'preview-url.txt'),url);
 process.on('SIGTERM',()=>server.close());
}else{
 const kind=process.argv[2]||'pitch';
 const timeline=JSON.parse(await readFile(resolve(here,'../audio',kind+'-timeline.json'),'utf8'));
 const browser=await chromium.launch({headless:true});
 const context=await browser.newContext({viewport:{width:1600,height:900},deviceScaleFactor:1,recordVideo:{dir:resolve(output,kind+'-raw'),size:{width:1600,height:900}}});
 const page=await context.newPage();
 const requests=[],errors=[],events=[];
 page.on('request',r=>requests.push({url:r.url(),method:r.method()}));
 page.on('pageerror',e=>errors.push(e.message));
 let execution,runComplete=false,stdout='',runError,child;
 try{
  await page.goto(url);
  const product=page.frameLocator('#product');
  await product.locator('#hash').filter({hasText:/[0-9a-f]{64}/}).waitFor({state:'attached'});
  const shot=async name=>{await page.screenshot({path:resolve(output,kind+'-'+name+'.png')});};
  if(kind==='pitch')await page.evaluate(scene=>window.studio.slide(scene,0),timeline.scenes[0]);
  else await page.evaluate(()=>window.studio.mode('product','01 / THE REAL VIEWER'));
  const start=performance.now();
  let sceneIndex=-1,captionIndex=-1;
  while(performance.now()-start < timeline.duration*1000){
   const seconds=(performance.now()-start)/1000;
   const next=timeline.scenes.findIndex(s=>seconds>=s.start && seconds<s.end);
   if(next!==-1 && next!==sceneIndex){
    sceneIndex=next;
    const scene=timeline.scenes[next];
    events.push({scene:scene.id,elapsed:seconds});
    console.log(kind,scene.id,seconds.toFixed(2));
    if(kind==='pitch')await page.evaluate(({scene,next})=>window.studio.slide(scene,next),{scene,next});
    else{
     await page.evaluate(label=>window.studio.mode('product',label),scene.label);
     if(scene.id==='intro')await product.locator('h1').scrollIntoViewIfNeeded();
     if(scene.id==='historical'){
      await product.locator('#scenario').selectOption('ethereum-uniswap-slippage');
      await product.locator('#source-pin').filter({hasText:'19000000'}).waitFor();
      await product.locator('.report-toolbar').scrollIntoViewIfNeeded();
     }
     if(scene.id==='source')await product.locator('#evm-details').scrollIntoViewIfNeeded();
     if(scene.id==='run'){
      await page.evaluate(label=>window.studio.mode('console',label),scene.label);
      const manifest=JSON.parse(await readFile('/tmp/entrotter-agent-worker/worker-image-final.json','utf8'));
      child=spawn('python3',[resolve(here,'live_run.py')],{cwd:workspace,env:{...process.env,PYTHONPATH:resolve(workspace,'.worktrees/engine-agent-worker/src'),ENTROTTER_DOCKER_SOCKET:resolve(process.env.HOME,'.colima/entrotter/docker.sock'),ENTROTTER_WORKER_IMAGE:manifest.image_id,ENTROTTER_EXPORT_STATE:resolve(output,'export-state')}});
      execution=new Promise((resolveRun,rejectRun)=>{child.on('error',rejectRun);child.on('close',code=>code===0?resolveRun():rejectRun(new Error('Real execution failed with '+code)));});
      execution.then(()=>runComplete=true).catch(e=>runError=e);
      child.stdout.on('data',data=>stdout+=data.toString());
      child.stderr.on('data',data=>stdout+=data.toString());
     }
     if(scene.id==='run_result'){
      await page.evaluate(label=>window.studio.mode('console',label),scene.label);
      assert(runComplete,'Actual execution did not finish in the narration window');
     }
     if(scene.id==='import'){
      assert(runComplete);
      await product.locator('#import').setInputFiles(resolve(output,'generated/agent-replay.json'));
      await product.locator('#hash').filter({hasText:'1d1de88d01cbe23c494f6a6f7ee7127d63629baac071def58c067506ddf5893b'}).waitFor();
      await product.locator('.report-toolbar').scrollIntoViewIfNeeded();
     }
     if(scene.id==='invalid'){
      await product.locator('#import').setInputFiles(resolve(output,'generated/invalid-hash.json'));
      await product.locator('#report-status.error').waitFor();
      await product.locator('#baseline-value').filter({hasText:/^—$/}).waitFor();
      assert.equal(await product.locator('#baseline-value').innerText(),'—');
      await product.locator('.report-toolbar').scrollIntoViewIfNeeded();
     }
     if(scene.id==='end')await page.evaluate(()=>window.studio.slide({id:'close',eyebrow:'REPRODUCE / REVIEW / CONTRIBUTE',title:'Bring one decision\nyou need to explain.',body:'entrotter.github.io · github.com/entrotter',lines:['19 reports reproduced · 12 agent records replayed','No demonstrated model or speed advantage','Open review branch · independent approval pending']},7));
    }
    await shot(scene.id);
   }
   if(runError)throw runError;
   if(kind==='demo' && ['run','run_result'].includes(timeline.scenes[sceneIndex]?.id))await page.evaluate(text=>window.studio.output(text),stdout);
   const cue=timeline.captions.findIndex(c=>seconds>=c.start&&seconds<c.end);
   if(cue!==captionIndex){
    captionIndex=cue;
    await page.evaluate(({text,pct})=>window.studio.caption(text,pct),{text:cue>=0?timeline.captions[cue].text:'',pct:Math.min(100,seconds/timeline.duration*100)});
    if(kind==='demo'&&cue>=0){
     const c=timeline.captions[cue];
     if(c.scene==='invalid'&&c.text.startsWith('Loading')){
      await product.locator('#import').setInputFiles(resolve(output,'generated/agent-replay.json'));
      await product.locator('#hash').filter({hasText:'1d1de88'}).waitFor();
      await shot('recovered');
     }
     if(c.scene==='import'&&c.text.startsWith('The source JSON')){
      await product.getByText('Full result JSON',{exact:true}).click();
      await product.locator('#raw-report').scrollIntoViewIfNeeded();
      await shot('record-json');
     }
    }
   }
   await new Promise(r=>setTimeout(r,80));
  }
  if(execution)await execution;
  assert.equal(errors.length,0);
  assert(requests.every(r=>r.url.startsWith(url+'/')&&r.method==='GET'));
  await writeFile(resolve(output,kind+'-capture.json'),JSON.stringify({kind,browser:browser.version(),duration:timeline.duration,capture_wall_seconds:(performance.now()-start)/1000,events,requests,errors,real_execution_complete:runComplete},null,2)+'\n');
  if(kind==='demo')await writeFile(resolve(output,'actual-execution.log'),stdout);
  const video=page.video();
  await context.close();
  await video.saveAs(resolve(output,kind+'-capture.webm'));
 }finally{
  if(child&&child.exitCode===null)child.kill('SIGTERM');
  await browser.close();
  await new Promise(r=>server.close(r));
 }
}
