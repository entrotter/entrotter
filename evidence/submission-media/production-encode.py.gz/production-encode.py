"""Mux continuous real browser capture and original synthetic narration; no time cuts."""
import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[3]
raw=root/'entrotter/output/playwright/submission'
out=root/'entrotter/submission/media'
tool=root/'.tools/entrotter-media'
results={}
for kind in ['pitch','demo']:
    source=raw/f'{kind}-capture.webm'
    probe=json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_format','-show_streams','-of','json',str(source)]))
    capture=json.loads((raw/f'{kind}-capture.json').read_text())
    duration=float(probe['format']['duration'])
    offset=max(0,duration-capture['capture_wall_seconds'])
    target=out/f'entrotter-{kind}.mp4'
    command=['ffmpeg','-y','-hide_banner','-i',str(source),'-itsoffset',str(offset),'-i',str(tool/'audio'/f'{kind}.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-ar','48000','-af','loudnorm=I=-16:TP=-1.5:LRA=11','-movflags','+faststart','-t',str(duration),'-metadata','title=Entrotter '+kind+' — review cut',str(target)]
    with (tool/f'{kind}-encode.log').open('w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    timeline=json.loads((tool/'audio'/f'{kind}-timeline.json').read_text())
    def stamp(value,comma=False):
        milliseconds=round(value*1000);seconds,ms=divmod(milliseconds,1000);minutes,s=divmod(seconds,60);h,m=divmod(minutes,60)
        return f'{h:02}:{m:02}:{s:02}'+(',' if comma else '.')+f'{ms:03}'
    vtt=['WEBVTT',''];srt=[]
    for i,c in enumerate(timeline['captions'],1):
        vtt += [f"{stamp(c['start']+offset)} --> {stamp(c['end']+offset)}",c['text'],'']
        srt += [str(i),f"{stamp(c['start']+offset,True)} --> {stamp(c['end']+offset,True)}",c['text'],'']
    (out/f'entrotter-{kind}.vtt').write_text('\n'.join(vtt)+'\n');(out/f'entrotter-{kind}.srt').write_text('\n'.join(srt)+'\n')
    final=json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_format','-show_streams','-of','json',str(target)]))
    assert float(final['format']['duration'])<=180
    assert sum(x['codec_type']=='video' for x in final['streams'])==1 and sum(x['codec_type']=='audio' for x in final['streams'])==1
    results[kind]={'audio_offset_seconds':offset,'continuous_capture_seconds':duration,'probe':final}
    (out/f'{kind}-probe.json').write_text(json.dumps(final,indent=2)+'\n')
    print(kind,final['format']['duration'],target.stat().st_size,flush=True)
(tool/'encode-results.json').write_text(json.dumps(results,indent=2)+'\n')
