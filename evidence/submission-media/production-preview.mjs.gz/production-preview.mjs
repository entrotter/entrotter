import {createRequire} from 'node:module';import{readFile,writeFile,mkdir}from'node:fs/promises';import{resolve}from'node:path';
const root=process.cwd();const require=createRequire(resolve(root,'entrotter.github.io/package.json'));const{chromium}=require('playwright');
const out=resolve(root,'entrotter/output/playwright/submission');const url=(await readFile(resolve(out,'preview-url.txt'),'utf8')).trim();const scenes=JSON.parse(await readFile(resolve(root,'.tools/entrotter-media/audio/pitch-timeline.json'),'utf8'));
const browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1600,height:900}});await page.goto(url);const checks=[];
for(const[index,scene]of scenes.scenes.entries()){
 const text=scenes.captions.filter(c=>c.scene===scene.id).sort((a,b)=>b.text.length-a.text.length)[0].text;
 await page.evaluate(({scene,index,text})=>{studio.slide(scene,index);studio.caption(text,100*(index+1)/8)},{scene,index,text});
 await page.screenshot({path:resolve(out,'preview-'+scene.id+'.png')});
 checks.push(await page.evaluate(()=>({title:document.querySelector('h1').textContent,slideBottom:document.querySelector('#slide ul').getBoundingClientRect().bottom,captionBottom:document.querySelector('#caption').getBoundingClientRect().bottom,metaTop:document.querySelector('#meta').getBoundingClientRect().top,overflow:document.documentElement.scrollHeight>900})));
}
await writeFile(resolve(out,'preview-layout.json'),JSON.stringify(checks,null,2));console.log(checks);await browser.close();
