"""Decode final review cuts and retain basic media integrity measurements."""
import json
import subprocess
from pathlib import Path
root = Path(__file__).resolve().parents[3]
tool = root / '.tools/entrotter-media'
media = root / 'entrotter/submission/media'
results = {}
for kind, sample in [('pitch', 79), ('demo', 135)]:
    path = media / f'entrotter-{kind}.mp4'
    command = ['ffmpeg', '-hide_banner', '-v', 'error', '-xerror', '-i', str(path), '-f', 'null', '-']
    decode = subprocess.run(command, capture_output=True, text=True, check=True)
    (tool / f'{kind}-decode.log').write_text(decode.stderr)
    command = ['ffmpeg', '-hide_banner', '-i', str(path), '-vn', '-af', 'ebur128=peak=true', '-f', 'null', '-']
    sound = subprocess.run(command, capture_output=True, text=True, check=True)
    (tool / f'{kind}-audio-analysis.log').write_text(sound.stderr)
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', str(sample), '-i', str(path), '-frames:v', '1', str(tool / f'{kind}-final-frame.png')], check=True)
    results[kind] = {'complete_decode_exit': decode.returncode, 'decode_stderr_bytes': len(decode.stderr), 'audio_analysis_exit': sound.returncode, 'sample_frame_seconds': sample, 'human_listening_review': 'pending'}
(tool / 'media-checks.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
