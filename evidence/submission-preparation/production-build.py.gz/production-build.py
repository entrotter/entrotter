import json,sys,wave,subprocess,hashlib,textwrap
from pathlib import Path
root=Path(__file__).resolve().parent
scenes=json.loads((root/'scenes.json').read_text())
voice_dir=root.parent/'entrotter-media'
if sys.argv[1]=='narrate':
 import onnxruntime
 from piper import PiperVoice,SynthesisConfig
 from piper.config import PiperConfig
 options=onnxruntime.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
 voice=PiperVoice(config=PiperConfig.from_dict(json.loads((voice_dir/'en_US-ljspeech-high.onnx.json').read_text())),session=onnxruntime.InferenceSession(str(voice_dir/'en_US-ljspeech-high.onnx'),sess_options=options,providers=['CPUExecutionProvider']),download_dir=voice_dir)
 for i,s in enumerate(scenes):
  with wave.open(str(root/f'{i}.wav'),'wb') as output:voice.synthesize_wav(s['narration'],output,syn_config=SynthesisConfig(length_scale=.93,noise_scale=.55,noise_w_scale=.7))
  with wave.open(str(root/f'{i}.wav'),'rb') as audio:s['audio_seconds']=audio.getnframes()/audio.getframerate()
  s['duration']=s['audio_seconds']+.8
 (root/'timing.json').write_text(json.dumps(scenes,indent=2)+'\n')
 print('total_seconds',sum(s['duration'] for s in scenes),flush=True)
else:
 from PIL import Image,ImageDraw,ImageFont
 scenes=json.loads((root/'timing.json').read_text())
 fontroot=Path('/System/Library/Fonts/Supplemental')
 def font(size,bold=False):return ImageFont.truetype(str(fontroot/('Arial Bold.ttf' if bold else 'Arial.ttf')),size)
 for i,s in enumerate(scenes):
  im=Image.new('RGB',(1280,720),'#100c1b');d=ImageDraw.Draw(im)
  d.rectangle((0,0,1280,6),fill='#b994ff')
  d.text((56,29),'entrotter',font=font(30,True),fill='#f7f4ff')
  d.text((880,38),'SYNTHETIC NARRATION',font=font(17),fill='#bda9d8')
  d.text((58,105),s['eyebrow'],font=font(17,True),fill='#b994ff')
  d.multiline_text((56,145),s['title'],font=font(47,True),fill='#f7f4ff',spacing=7)
  y=295
  for point in s['points']:
   d.ellipse((60,y+9,66,y+15),fill='#b994ff');d.text((83,y),point,font=font(24),fill='#d8cce8');y+=45
  d.text((58,475),f'{i+1:02d} / 06   ·   EXPERIMENTAL · LIMITATIONS DISCLOSED',font=font(16),fill='#ae9bbf')
  d.rectangle((0,525,1280,720),fill='#21172e')
  lines=textwrap.wrap(s['narration'],width=101)
  d.multiline_text((56,550),'\n'.join(lines),font=font(23),fill='#ffffff',spacing=8)
  if len(lines)>5:raise ValueError('Caption too long')
  im.save(root/f'{i}.png')
  command=['/opt/homebrew/bin/ffmpeg','-y','-hide_banner','-loglevel','error','-loop','1','-framerate','25','-i',str(root/f'{i}.png'),'-i',str(root/f'{i}.wav'),'-t',str(s['duration']),'-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-ar','48000','-af','apad,loudnorm=I=-16:TP=-1.5:LRA=11','-movflags','+faststart',str(root/f'{i}.mp4')]
  subprocess.run(command,check=True)
 (root/'concat.txt').write_text(''.join(f"file '{i}.mp4'\n" for i in range(len(scenes))))
 out=root.parent.parent/'entrotter/submission/media/entrotter-pitch-short.mp4'
 subprocess.run(['/opt/homebrew/bin/ffmpeg','-y','-hide_banner','-loglevel','error','-f','concat','-safe','0','-i',str(root/'concat.txt'),'-c','copy','-movflags','+faststart',str(out)],check=True)
 probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-show_format','-show_streams','-of','json',str(out)],text=True))
 duration=float(probe['format']['duration'])
 if duration>120:raise ValueError(f'Pitch exceeds 120 seconds: {duration}')
 subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(out),'-f','null','-'],check=True)
 def stamp(t):
  ms=round(t*1000); sec,ms=divmod(ms,1000);mins,sec=divmod(sec,60)
  return f'00:{mins:02d}:{sec:02d}.{ms:03d}'
 cursor=0;captions=['WEBVTT','']
 for i,s in enumerate(scenes):
  clip=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-show_format','-of','json',str(root/f'{i}.mp4')],text=True))
  span=float(clip['format']['duration']); captions += [f'{stamp(cursor)} --> {stamp(cursor+s["audio_seconds"])}',s['narration'],''];cursor+=span
 out.with_suffix('.vtt').write_text('\n'.join(captions)+'\n')
 evidence={'duration_seconds':duration,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'complete_decode':'passed','format':'H.264 1280x720 25fps / AAC 48kHz','construction':'Six original presentation cards, newly synthesized narration, embedded captions; not a live product demo or founder voice recording. Existing separate demo remains unchanged.','voice_model_sha256':hashlib.sha256((voice_dir/'en_US-ljspeech-high.onnx').read_bytes()).hexdigest()}
 (root/'verification.json').write_text(json.dumps(evidence,indent=2)+'\n');print(json.dumps(evidence),flush=True)
